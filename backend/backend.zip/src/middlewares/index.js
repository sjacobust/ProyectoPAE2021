const authMiddleware = require("./authMiddleware");

module.exports = {
    authMiddleware,
}