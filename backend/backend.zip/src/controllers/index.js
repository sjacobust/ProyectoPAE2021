const DishesController = require("./dishes.controller");
const UsersController = require("./users.controller");
const IngredientsController = require("./ingredients.controller");

module.exports = {
    DishesController,
    UsersController,
    IngredientsController
}