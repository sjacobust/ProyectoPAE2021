const users = require("./user");
const token = require("./token");
const dishes = require("./dishes");
const ingredients = require('./ingredients');


module.exports = {
    users,
    token,
    dishes,
    ingredients
}